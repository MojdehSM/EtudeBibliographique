package DataModel;

public enum OpenStreetMapType {
	tags,
	members,
	element,
	node,
	way,
	relation,
	nd,
}
